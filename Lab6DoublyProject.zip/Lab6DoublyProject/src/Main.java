public class Main {
    public static void main(String[] args) {

        DoublyCircularClass list=new DoublyCircularClass();
        list.insert(0,13,"Muneeb",4,"Fever");
        list.insertStart(11,"Noman",3,"CholoroPethic");
        list.insertEnd(23,"Salman",7,"Typhoid");
        list.insert(3,1,"Salma",9,"cancer");
        list.insertEnd(19,"Wajahat",11,"Fever");
        list.insertStart(2,"Ahmed",43,"Dementia");

        list.sortList();
        list.update(5,56,"Usman",21,"Piles");

        list.deleteFirst();
        list.deleteEnd();
        list.delete(2);
        list.deleteValue(11);
        list.insert(1,90,"Rehman",33,"Fever");
        list.insert(2,91,"Usama",54,"Kidney Fail");
        list.sortList();
        list.printList();
        list.searchNode(90);
        System.out.println();

        DoublyCircularClass l2=new DoublyCircularClass();
        l2.insertStart(467,"Furqan",44,"None");
        l2.insertEnd(411,"Abdullah",56,"Fever");
        l2.insert(1,31,"Shuja",21,"Tortolla");
        l2.printList();
        System.out.println();
        list.merge(l2);
        list.sortList();
        list.printList();
        list.deleteValue(467);
        list.delete(0);
        list.update(3,92,"Suman",6,"Typhoid");
        System.out.println();
        list.printList();
        list.searchNode(411);
        System.out.println();
        list.reverse();
        list.printList();

        DoublyCircularClass l3=new DoublyCircularClass();
        list.clone(l3);
        l3.printList();
        l3.searchNode(19);
        list.jp(3);
        System.out.println();
        list.printList();
    }
}