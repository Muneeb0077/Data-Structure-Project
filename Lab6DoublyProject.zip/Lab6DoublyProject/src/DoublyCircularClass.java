public class DoublyCircularClass {
    private Patient head;
    private int k;

    public Patient getHead() {
        return head;
    }

    public int getK() {
        return k;
    }

    public void insertStart(int id,String name,int bedNo,String disease){
        Patient newNode=new Patient(id, name, bedNo, disease);

        if(head==null){
            head=newNode;
            head.setNext(head);
            head.setPrevious(head);
            k=k+1;
        }
        else {
            Patient ptr=head;
            while(ptr.getNext()!=head){
                ptr=ptr.getNext();
            }
            ptr.setNext(newNode);
            newNode.setPrevious(ptr);
            newNode.setNext(head);
            head.setPrevious(newNode);
            head=newNode;
            k=k+1;
        }
    }

    public void insertEnd(int id,String name,int bedNo,String disease){
        Patient newNode=new Patient(id, name, bedNo, disease);
        if(head==null){
            insertStart(id, name, bedNo, disease);
        }
        else{
            Patient ptr=head;
            while(ptr.getNext()!=head){
                ptr=ptr.getNext();
            }
            ptr.setNext(newNode);
            newNode.setPrevious(ptr);
            newNode.setNext(head);
            head.setPrevious(newNode);
            k=k+1;
        }
    }

    public void insert(int index,int id,String name,int bedNo,String disease){
        Patient newNode=new Patient(id, name, bedNo, disease);
        if(index>=0&&index<=k){
            if(index==0){
                insertStart(id, name, bedNo, disease);
            }
            else if(index==k){
                insertEnd(id, name, bedNo, disease);
            }
            else {
                Patient ptr=head;
                for (int i = 0; i < index - 1; i++) {
                    ptr = ptr.getNext();
                }
                newNode.setNext(ptr.getNext());
                ptr.getNext().setPrevious(newNode);
                newNode.setPrevious(ptr);
                ptr.setNext(newNode);
                k=k+1;
            }
        }

    }

    public Patient deleteFirst(){
        if(head!=null){
            if(head.getNext()==head){
                Patient ptr=head;
                head=null;
                k=k-1;
                return ptr;
            }
            else{
                Patient ptr=head;
                head.getPrevious().setNext(head.getNext());
                head.getNext().setPrevious(head.getPrevious());
                head=head.getNext();
                k=k-1;
                return ptr;
            }
        }
        else
            System.out.println("List is empty");
        return null;
    }

    public Patient deleteEnd(){
        if(head!=null) {
            if (head.getNext() == head) {
                deleteFirst();
            }
            else{
                Patient ptr=null;
                Patient qtr=head;
                while(qtr.getNext()!=head){
                    ptr=qtr;
                    qtr=qtr.getNext();
                }
                ptr.setNext(head);
                head.setPrevious(ptr);
                qtr.setNext(null);
                qtr.setPrevious(null);
                k=k-1;
                return qtr;

            }
        }
        else
            System.out.println("List is empty");
        return null;
    }

    public Patient delete(int index){
        if(index>=0&&index<k) {
            if (index == 0) {
                deleteFirst();
            }
            else{
                Patient ptr=head;
                for(int i=0;i<index-1;i++){
                    ptr=ptr.getNext();
                }
                Patient hold=ptr.getNext();
                ptr.setNext(hold.getNext());
                hold.getNext().setPrevious(ptr);
                hold.setPrevious(null);
                hold.setNext(null);
                k=k-1;
                return hold;
            }
        }
        else
            System.out.println("Invalid index");
        return null;
    }

    public Patient deleteValue(int value){
        if(head!=null) {
            Patient ptr = head;
            Patient qtr = head.getNext();

            if (ptr.getId() == value) {
                deleteFirst();
            } else {
                while (qtr.getId() != value && qtr.getNext() != head) {
                    ptr = ptr.getNext();
                    qtr = qtr.getNext();
                }
                if (qtr.getId() == value) {
                    Patient hold = ptr.getNext();
                    ptr.setNext(hold.getNext());
                    hold.getNext().setPrevious(ptr);
                    hold.setPrevious(null);
                    hold.setNext(null);
                    k = k - 1;
                    return hold;

                } else if (qtr.getId() != value)
                    System.out.println("Id not found");
            }
        }
        return null;
    }

    public void sortList(){
        Patient ptr=head;
        Patient qtr=null;

        do{
            qtr=ptr.getNext();
            do{

                if(ptr.getId()>=qtr.getId()){
                    int t= ptr.getId();
                    String n=ptr.getName();
                    int b=ptr.getBedNo();
                    String d= ptr.getDisease();

                    ptr.setId(qtr.getId());
                    qtr.setId(t);

                    ptr.setName(qtr.getName());
                    qtr.setName(n);

                    ptr.setBedNo(qtr.getBedNo());
                    qtr.setBedNo(b);

                    ptr.setDisease(qtr.getDisease());
                    qtr.setDisease(d);

                }
                qtr=qtr.getNext();
            }while(qtr!=head);
            ptr=ptr.getNext();
        }while(ptr.getNext()!=head);

    }

    public Patient searchNode(int value){
        Patient ptr=head;
        int count=0;
        do{
            if(ptr.getId()==value){
                System.out.println("Value found at index "+count);
                return ptr;
            }
            else {
                ptr = ptr.getNext();
                count++;
            }
        }while(ptr.getNext()!=head);
        if(ptr.getId()==value){
            System.out.println("Value found at index "+count);
            return ptr;
        }
        else return null;
    }

    public void update(int index,int id,String name,int bedNo,String disease){
        if(index>=0&&index<k){
            if(index==0){
                head.setId(id);
                head.setName(name);
                head.setBedNo(bedNo);
                head.setDisease(disease);
            }
            else {
                Patient ptr=head;
                for(int i=0;i<index;i++){
                    ptr=ptr.getNext();
                }
                ptr.setId(id);
                ptr.setName(name);
                ptr.setBedNo(bedNo);
                ptr.setDisease(disease);
            }
        }
    }

    public void merge(DoublyCircularClass l1){
        Patient ptr=head;
        Patient qtr=l1.head;
        while(qtr.getNext()!=l1.head){
            qtr=qtr.getNext();
        }
        qtr.setNext(head);
        head.setPrevious(qtr);
        while(ptr.getNext()!=head){
            ptr=ptr.getNext();
        }
        ptr.setNext(l1.head);
        l1.head.setPrevious(ptr);
        k=l1.k+k;
    }

    public void reverse(){
        if(head!=null) {
            Patient pre = head;
            Patient temp = head;
            Patient curr = head.getNext();

            pre.setNext(pre);
            pre.setPrevious(pre);

            while (curr != head) {
                temp = curr.getNext();

                curr.setNext(pre);
                pre.setPrevious(curr);
                head.setNext(curr);
                curr.setPrevious(head);

                pre = curr;
                curr = temp;

            }
            head=pre;
        }

    }

    public Patient getData(int index){
        if(head!=null){
            Patient ptr=head;
            for(int i=0;i<index;i++){
                ptr=ptr.getNext();
            }
            return ptr;
        }
        return null;
    }

    public void clone(DoublyCircularClass l2){

        for(int i=0;i<k;i++){
            l2.insert(i,getData(i).getId(),getData(i).getName(),getData(i).getBedNo(),getData(i).getDisease());
        }



    }

    public void jp(int value){
        if(head!=null&&head.getNext()!=head) {

            for (int i = 1; i < k; i++) {
                if (i%value == 0) {
                    delete(i);
                }
            }
        }

    }
    public void printList(){
        if(head!=null) {
            Patient ptr = head;
            while (ptr.getNext() != head) {
                System.out.println(ptr.getId());
                System.out.println(ptr.getName());
                System.out.println(ptr.getBedNo());
                System.out.println(ptr.getDisease());
                System.out.println();
                ptr = ptr.getNext();
            }
            System.out.println(ptr.getId());
            System.out.println(ptr.getName());
            System.out.println(ptr.getBedNo());
            System.out.println(ptr.getDisease());
            System.out.println();
        }
        else
            System.out.println("List is empty");
    }
}
