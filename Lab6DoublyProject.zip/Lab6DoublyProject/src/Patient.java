public class Patient {
    private int id;
    private String name;
    private int bedNo;
    private String disease;

    private Patient next;
    private Patient previous;

    public Patient(int id, String name, int bedNo, String disease) {
        this.id = id;
        this.name = name;
        this.bedNo = bedNo;
        this.disease = disease;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBedNo(int bedNo) {
        this.bedNo = bedNo;
    }

    public void setDisease(String disease) {
        this.disease = disease;
    }

    public void setNext(Patient next) {
        this.next = next;
    }

    public void setPrevious(Patient previous) {
        this.previous = previous;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getBedNo() {
        return bedNo;
    }

    public String getDisease() {
        return disease;
    }

    public Patient getNext() {
        return next;
    }

    public Patient getPrevious() {
        return previous;
    }
}
